#
# Copyright (c) 2020 Red Hat Training <training@redhat.com>
#
# All rights reserved.
# No warranty, explicit or implied, provided.
#
# CHANGELOG
#   * Mon Oct 05 2020 Your Name <yname@redhat.com>
#   - original code

"""
Grading module for RH000 LAB_OR_GE_TITLE guided exercise (or lab).

This module either does start, grading, or finish for the
LAB_OR_GE_TITLE guided exercise (or lab).
"""

#########################################################################
#                   How to use this template:
#
# 1. Rename the file to SomethingRelatedToYourLab.py. Use WordCaps,
#    do not use dashes or underscores.
# 2. Adjust the CHANGELOG and docstring above.
# 3. Define the hosts that are used in this activity in the _targets list.
# 4. Rename the class. The name of the class must match the file name
#    (without the .py extension)
# 5. Remove the methods (start, finish, or grade) that your lab script
#    does not support.
# 6. Remove these "How to use this template" comments
#########################################################################

# TODO: Implement common file copy wrapper functions

import os
import pkg_resources
import requests

from urllib3 import disable_warnings
from urllib3.exceptions import InsecureRequestWarning
from ocp import api
from labs.grading import Default
from labs.common import labtools, userinterface

# List of hosts involved in that module. Before doing anything,
# the module checks that they can be reached on the network
_targets = [
    "localhost",
    # "server-a",
    # "server-b",
    # "classroom",
    # "bastion",
]

# Get the OCP host and port from environment variables
OCP_API = {
    "host": os.environ.get("OCP_HOST", "api.ocp4.example.com"),
    "port": os.environ.get("OCP_PORT", "6443"),
}


# Change the class name to match your file name
class ExampleOpenshift(Default):
    """
    Example OpenShift lab script for GL006
    """
    __LAB__ = "example-openshift"

    # The following methods define which subcommands are supported
    # (start, grade, finish).
    # Remove the methods you do not need.

    def start(self):
        """
        Prepare the system for starting the lab
        """
        # The items dictionnary lists the tasks to run in order.
        # Each item describes a task. It is a dictionnary with the following
        # keys:
        #     label: Short, one line description of the task.
        #      task: Method or function to run. If not set, or set to None,
        #            nothing is executed for that step.
        #    failed: This is the result of the task execution. The function
        #            defined by the "task" key must set that status to True or
        #            False. This status is used to display the completion
        #            status of the task.
        #      msgs: List of error messages. Those messages may be set by the
        #            "task" function when the task fails. They are
        #            displayed to provide additional information to students.
        #            Each message in the list is a dictionnary with the key
        #            set to "text" and the text message as a value.
        #            For example:
        #              { "text": "The system cannot be reached"}
        items = [
            {
                "label": "Checking lab systems",
                "task": labtools.check_host_reachable,
                "hosts": _targets,
                "fatal": True,
            },
            {
                "label": "PING API",
                "task": self._start_ping_api,
                "host": OCP_API["host"],
                "fatal": True,
            },
            {
                "label": "Check API",
                "task": self._start_check_api,
                "host": OCP_API["host"],
                "port": OCP_API["port"],
                "fatal": True,
            },
            {
                "label": "Cluster Ready",
                "task": self._start_check_cluster_ready,
                "fatal": True,
            },
            {
                "label": "Configuration deployed",
                "task": self._start_conf_deployed,
            },
            {
                "label": "Create resources",
                "task": self._start_create_resources,
            },
        ]
        userinterface.Console(items).run_items(action="Starting")

    def grade(self):
        """
        Perform evaluation steps on the system
        """
        items = [
            {
                "label": "Checking lab systems",
                "task": labtools.check_host_reachable,
                "hosts": _targets,
                "fatal": True,
            },
            {
                "label": "Configuration file exists",
                "task": self._grade_check_conf,
            },
            {
                "label": "Check resources",
                "task": self._grade_check_resources,
            },
            {
                "label": "Check route",
                "task": self._grade_check_route,
            },
        ]
        ui = userinterface.Console(items)
        ui.run_items(action="Grading")
        ui.report_grade()

    def finish(self):
        """
        Perform post-lab cleanup
        """
        items = [
            {
                "label": "Checking lab systems",
                "task": labtools.check_host_reachable,
                "hosts": _targets,
                "fatal": True,
            },
            {
                "label": "Remove resources",
                "task": self._finish_remove_resources},
            {
                "label": "Remove student's working directory",
                "task": self._finish_workdir,
            },
        ]
        userinterface.Console(items).run_items(action="Finishing")

    # Start tasks

    def _start_ping_api(self, item):
        """
        Execute a task to prepare the system for the lab
        """
        if item["host"] is None:
            item["failed"] = True
            item["msgs"] = [{"text": "OCP_HOST is not defined"}]
        else:
            check = labtools.ping(item["host"])
            for key in check:
                item[key] = check[key]

        # Return status to abort lab execution when failed
        return item["failed"]

    def _start_check_api(self, item):
        if item["host"] is None or item["port"] is None:
            item["failed"] = True
            item["msgs"] = [{"text": "OCP_HOST and OCP_PORT are not defined"}]
        else:
            if api.isApiUp(item["host"], port=item["port"]):
                item["failed"] = False
            else:
                item["failed"] = True
                item["msgs"] = [
                    {
                        "text": "API could not be reached: "
                        + "https://{}:{}/".format(item["host"], item["port"])
                    }
                ]

        # Return status to abort lab execution when failed
        return item["failed"]

    def _start_check_cluster_ready(self, item):
        oc_client = api.getOpenShiftClient()

        # Get resources from cluster to check API
        oc_client.resources.get(
            api_version="project.openshift.io/v1", kind="Project"
        ).get()
        oc_client.resources.get(api_version="v1", kind="Node").get()
        oc_client.resources.get(api_version="v1", kind="Namespace").get()

        # This only applies for OpenShift, not minishift
        try:
            v1_config = oc_client.resources.get(
                api_version="config.openshift.io/v1", kind="ClusterVersion"
            )
            cluster_version = v1_config.get().items[0]
            if cluster_version.spec.clusterID is None:
                item["failed"] = True
                item["msgs"] = [{"text": "Cluster ID could not be found"}]
            else:
                item["failed"] = False
        except Exception:
            item["msgs"] = [{"text": "Cluster is not OpenShift"}]

    def _start_conf_deployed(self, item):
        """
        Create a sample file in ~/SKU/lab_name
        """
        lab_name = type(self).__name__
        student_working_dir = os.path.join(
            labtools.get_sku_path(),
            lab_name
        )

        # Create the ~/SKU/lab_name directory with a wrapper function
        mkdir_result = labtools.mkdir(student_working_dir)
        if mkdir_result["failed"]:
            item["failed"] = True
            item["msgs"] = [{"text": "Directory could not be created"}]
            return

        # Create a test_file inside ~/SKU/lab_name with native Python code
        src = os.path.join(
            pkg_resources.resource_filename(__name__, "materials"),
            lab_name,
            "namespace.yaml",
        )
        cp_result = labtools.cp(src, lab_name)
        if cp_result["failed"]:
            item["failed"] = True
            item["msgs"] = [{"text": "File could not be copied"}]
            return

    def _start_create_resources(self, item):
        lab_name = type(self).__name__
        lab_dir = os.path.join(
            pkg_resources.resource_filename(__name__, "materials"),
            lab_name,
        )
        disable_warnings(InsecureRequestWarning)
        oc_client = api.getOpenShiftClient()
        namespace = "example"

        # A wrapper function is used to simplify operations
        # rht-labs-ocp.ocp.api.apply_resource
        try:
            # Create project
            project_file = os.path.join(lab_dir, "project.yaml")
            api.apply_resource(
                oc_client, project_file,
                api_version="project.openshift.io/v1",
                kind="Project",
                namespace=None,
                verb="create"
            )

            # # Create namespace (created with "project" in OCP)
            # namespace_file = os.path.join(lab_dir, "namespace.yaml")
            # api.apply_resource(
            #     oc_client, namespace_file,
            #     api_version="v1",
            #     kind="Namespace",
            #     namespace=None,
            #     verb="create"
            # )

            # Create serviceaccount
            deployment_file = os.path.join(lab_dir, "serviceaccount.yaml")
            api.apply_resource(
                oc_client, deployment_file,
                api_version="v1",
                kind="ServiceAccount",
                namespace=namespace,
                verb="create"
            )

            # Create or patch clusterrolebinding
            clusterrolebinding_file = os.path.join(
                lab_dir, "clusterrolebinding.yaml"
            )
            try:
                api.apply_resource(
                    oc_client, clusterrolebinding_file,
                    api_version="rbac.authorization.k8s.io/v1",
                    kind="ClusterRoleBinding",
                    namespace=namespace,
                    verb="create"
                )
            except Exception:
                api.patch_resource(
                    oc_client, clusterrolebinding_file,
                    api_version="rbac.authorization.k8s.io/v1",
                    kind="ClusterRoleBinding",
                    namespace=namespace,
                    verb="patch"
                )

            # Create deployment
            deployment_file = os.path.join(lab_dir, "deployment.yaml")
            api.apply_resource(
                oc_client, deployment_file,
                api_version="apps/v1",
                kind="Deployment",
                namespace=namespace,
                verb="create"
            )

            # Create service
            service_file = os.path.join(lab_dir, "service.yaml")
            api.apply_resource(
                oc_client, service_file,
                api_version="v1",
                kind="Service",
                namespace=namespace,
                verb="create"
            )

            # Create route
            route_file = os.path.join(lab_dir, "route.yaml")
            api.apply_resource(
                oc_client, route_file,
                api_version="route.openshift.io/v1",
                kind="Route",
                namespace=namespace,
                verb="create"
            )
            item["failed"] = False

        except Exception as e:
            item["failed"] = True
            item["msgs"] = [{"text": "Could not create resources"}]
            item["exception"] = {
                "name": e.__class__.__name__,
                "message": str(e),
            }
        return item["failed"]

    # Grading tasks

    def _grade_check_conf(self, item):
        """
        Test that the configuration file exists in student's working directory
        """
        lab_name = type(self).__name__
        student_working_dir = os.path.join(
            labtools.get_sku_path(),
            lab_name
        )
        conf_file = os.path.join(student_working_dir, "namespace.yaml")

        if not os.path.isfile(conf_file):
            item["failed"] = True
            item["msgs"] = [
                {
                    "text":
                        "Configuration file missing: {}".format(conf_file)
                }
            ]
        else:
            item["failed"] = False

    def _grade_check_resources(self, item):
        disable_warnings(InsecureRequestWarning)
        oc_client = api.getOpenShiftClient()
        namespace = "example"

        try:
            # Get project
            oc_client.resources.get(
                api_version="project.openshift.io/v1",
                kind="Project"
            ).get(name=namespace)
            # Get namespace
            oc_client.resources.get(
                api_version="v1",
                kind="Namespace"
            ).get(name=namespace)
            # Get deployment
            oc_client.resources.get(
                api_version="apps/v1",
                kind="Deployment"
            ).get(name="nginx", namespace=namespace)
            # Get service
            oc_client.resources.get(
                api_version="v1",
                kind="Service"
            ).get(name="nginx", namespace=namespace)
            # Get route
            oc_client.resources.get(
                api_version="route.openshift.io/v1",
                kind="Route"
            ).get(name="nginx", namespace=namespace)

            item["failed"] = False
        except Exception as e:
            item["failed"] = True
            item["msgs"] = [{"text": "Could not get resources"}]
            item["exception"] = {
                "name": e.__class__.__name__,
                "message": str(e),
            }
        return item["failed"]

    def _grade_check_route(self, item):
        disable_warnings(InsecureRequestWarning)
        oc_client = api.getOpenShiftClient()
        namespace = "example"

        try:
            # Get route
            route = oc_client.resources.get(
                api_version="route.openshift.io/v1", kind="Route"
            ).get(name="nginx", namespace=namespace)

            # Test the route resource to see if pods are working ok
            route_url = "https://{}/".format(route["spec"]["host"])
            response = requests.get(route_url, verify=False)
            if response.status_code != 200:
                item["failed"] = True
                item["msgs"] = [{"text": "Route HTTP status code is not 200"}]
            else:
                item["failed"] = False

        except Exception as e:
            item["failed"] = True
            item["msgs"] = [{"text": "Could not get resources"}]
            item["exception"] = {
                "name": e.__class__.__name__,
                "message": str(e),
            }
        return item["failed"]

    def _grade_test(self, item):
        item["failed"] = False

    # Finish tasks

    def _finish_remove_resources(self, item):
        disable_warnings(InsecureRequestWarning)
        oc_client = api.getOpenShiftClient()
        namespace = "example"

        try:
            # Delete route
            oc_client.resources.get(
                api_version="route.openshift.io/v1",
                kind="Route"
            ).delete(name="nginx", namespace=namespace)
            # Delete service
            oc_client.resources.get(
                api_version="v1",
                kind="Service"
            ).delete(name="nginx", namespace=namespace)
            # Delete deployment
            oc_client.resources.get(
                api_version="v1",
                kind="Deployment"
            ).delete(name="nginx", namespace=namespace)
            # Delete namespace (removed when "project" is deleted in OCP)
            # oc_client.resources.get(
            #     api_version="v1",
            #     kind="Namespace"
            # ).delete(name=namespace)
            # Delete project
            oc_client.resources.get(
                api_version="project.openshift.io/v1",
                kind="Project"
            ).delete(name=namespace)
            item["failed"] = False

        except Exception as e:
            item["failed"] = True
            item["msgs"] = [{"text": "Could not delete resources"}]
            item["exception"] = {
                "name": e.__class__.__name__,
                "message": str(e),
            }
        return item["failed"]

    def _finish_workdir(self, item):
        """
        Remove student's working directory ~/SKU/lab_name
        """
        lab_name = type(self).__name__
        # Removing the ~/SKU/lab_name directory
        if not labtools.rmdir(lab_name, recursive=True):
            item["failed"] = True
            item["msgs"] = [{"text": "Directory could not be removed"}]
            return

        # Note: This section is commented out because we should not
        # remove the ~/SKU directory
        # # Remove the ~/SKU directory
        # try:
        #     shutil.rmtree(labtools.get_sku_path())
        # except OSError as e:
        #     item["failed"] = True
        #     item["msgs"] = [{"text": e}]
        # else:
        #     item["failed"] = False
