#
# Copyright (c) 2020 Red Hat Training <training@redhat.com>
#
# All rights reserved.
# No warranty, explicit or implied, provided.
#
# CHANGELOG
#   * Mon Oct 05 2020 Your Name <yname@redhat.com>
#   - original code

"""
Grading module for RH000 LAB_OR_GE_TITLE guided exercise (or lab).

This module either does start, grading, or finish for the
LAB_OR_GE_TITLE guided exercise (or lab).
"""

#########################################################################
#                   How to use this template:
#
# 1. Rename the file to SomethingRelatedToYourLab.py. Use WordCaps,
#    do not use dashes or underscores.
# 2. Adjust the CHANGELOG and docstring above.
# 3. Define the hosts that are used in this activity in the _targets list.
# 4. Rename the class. The name of the class must match the file name
#    (without the .py extension)
# 5. Remove the methods (start, finish, or grade) that your lab script
#    does not support.
# 6. Remove these "How to use this template" comments
#########################################################################

# FIXME: Catching too general exception 'Exception' (broad-except)

import os
import stat
import subprocess
import pkg_resources

from labs.grading import Default
from labs.common import labtools, userinterface
from labs.lab import LabError

# List of hosts involved in that module. Before doing anything,
# the module checks that they can be reached on the network
_targets = [
    "localhost",
    # "server-a",
    # "server-b",
    # "classroom",
    # "bastion",
]


# Change the class name to match your file name with WordCaps
class ExamplePythonLinux(Default):
    """
    Example Python lab script for GL006
    """
    __LAB__ = "example-python-linux"

    # The following methods define which subcommands are supported
    # (start, grade, finish).
    # Remove the methods you do not need.

    def start(self):
        """
        Prepare the system for starting the lab
        """
        # The items dictionnary lists the tasks to run in order.
        # Each item describes a task. It is a dictionnary with the following
        # keys:
        #     label: Short, one line description of the task.
        #      task: Method or function to run. If not set, or set to None,
        #            nothing is executed for that step.
        #    failed: This is the result of the task execution. The function
        #            defined by the "task" key must set that status to True or
        #            False. This status is used to display the completion
        #            status of the task.
        #      msgs: List of error messages. Those messages may be set by the
        #            "task" function when the task fails. They are
        #            displayed to provide additional information to students.
        #            Each message in the list is a dictionnary with the key
        #            set to "text" and the text message as a value.
        #            For example:
        #              { "text": "The system cannot be reached"}
        items = [
            {
                "label": "Checking lab systems",
                "task": labtools.check_host_reachable,
                "hosts": _targets,
                "fatal": True,
            },
            {
                "label": "PING host",
                "task": self._start_ping_host,
                "host": "localhost",
                "fatal": True,
            },
            {
                "label": "Check Red Hat release",
                "task": self._start_check_release,
            },
            {
                "label": "Check system services",
                "task": self._start_check_services,
            },
            {
                "label": "Configuration deployed",
                "task": self._start_conf_deployed,
            },
        ]
        userinterface.Console(items).run_items(action="Starting")

    def grade(self):
        """
        Perform evaluation steps on the system
        """
        items = [
            {
                "label": "Checking lab systems",
                "task": labtools.check_host_reachable,
                "hosts": _targets,
                "fatal": True,
            },
            {
                "label": "Check sshd_config owner and permissions",
                "task": self._grade_check_sshd_config,
            },
            {
                "label": "Configuration file exists",
                "task": self._grade_check_conf,
            },
        ]
        ui = userinterface.Console(items)
        ui.run_items(action="Grading")
        ui.report_grade()

    def finish(self):
        """
        Perform post-lab cleanup
        """
        items = [
            {
                "label": "Checking lab systems",
                "task": labtools.check_host_reachable,
                "hosts": _targets,
                "fatal": True,
            },
            {
                "label": "Remove student's working directory",
                "task": self._finish_workdir,
            },
        ]
        userinterface.Console(items).run_items(action="Finishing")

    # Start tasks

    def _start_ping_host(self, item):
        """
        Execute a task to prepare the system for the lab
        """
        check = labtools.ping(item["host"])
        for key in check:
            item[key] = check[key]
        # Return status to abort lab execution when failed
        return item["failed"]

    def _start_check_release(self, item):
        """
        Check if workstation is running RHEL
        """

        check = labtools.grep(
            "/etc/redhat-release",
            "Red Hat Enterprise Linux"
        )
        for key in check:
            item[key] = check[key]

        # Return status to abort lab execution when failed
        return item["failed"]

    def _start_check_services(self, item):
        """
        Check that system services are running
        """
        # Note: This task can be performed with the systemd python
        # module but we need to compile it when installing via pip
        services = [
            "chronyd",
            "rsyslog",
            "sshd",
            "systemd-journald",
            "systemd-udevd",
            # Uncomment the following to make the task fail
            # "systemd-binfmt",
            # "systemd-timesyncd",
        ]
        for service in services:
            try:
                for check in ("is-enabled", "is-active"):
                    subprocess.run(
                        ["systemctl", check, service],
                        timeout=1,
                        check=True,
                        stdin=subprocess.DEVNULL,
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                    )
                item["failed"] = False
            except Exception as e:
                item["failed"] = True
                item["msgs"] = [
                    {
                        "text":
                            "Service is not " +
                            "'enabled' and 'active':" +
                            " {}".format(service)
                    }
                ]
                item["exception"] = {
                    "name": e.__class__.__name__,
                    "message": str(e),
                }
        # Return status to abort lab execution when failed
        return item["failed"]

    def _start_conf_deployed(self, item):
        """
        Create a sample file in ~/SKU/lab_name
        """
        lab_name = type(self).__name__
        student_working_dir = os.path.join(
            labtools.get_sku_path(),
            lab_name
        )

        # Create the ~/SKU/lab_name directory with a wrapper function
        mkdir_result = labtools.mkdir(student_working_dir)
        if mkdir_result["failed"]:
            item["failed"] = True
            item["msgs"] = [{"text": "Directory could not be created"}]
            return

        # Create a test_file inside ~/SKU/lab_name with native Python code
        src = os.path.join(
            pkg_resources.resource_filename(__name__, "materials"),
            lab_name,
            "test.conf",
        )
        cp_result = labtools.cp(src, lab_name)
        if cp_result["failed"]:
            item["failed"] = True
            item["msgs"] = [{"text": "File could not be copied"}]
            return

    # Grading tasks

    def _grade_check_sshd_config(self, item):
        """"""
        path = "/etc/ssh/sshd_config"
        try:
            file_stat = os.stat(path)
            stat_info = stat.S_IMODE(file_stat.st_mode)

            # File must be owned by root:root
            if not (file_stat.st_uid == 0 and file_stat.st_gid == 0):
                raise LabError("File is not owned by 'root:root'")

            # File must be mode 0600
            if stat_info != (stat.S_IRUSR | stat.S_IWUSR):
                raise LabError("File does not have '0600' permissions")

            item["failed"] = False
        except LabError as e:
            item["failed"] = True
            item["msgs"] = [
                {
                    "text":
                        "File does not have desired" +
                        "owner and permissions:" +
                        " {}".format(path)
                }
            ]
            item["exception"] = {
                "name": e.__class__.__name__,
                "message": str(e),
            }

    def _grade_check_conf(self, item):
        """
        Test that the configuration file exists in student's working directory
        """
        lab_name = type(self).__name__
        student_working_dir = os.path.join(
            labtools.get_sku_path(),
            lab_name
        )
        conf_file = os.path.join(student_working_dir, "test.conf")

        if not os.path.isfile(conf_file):
            item["failed"] = True
            item["msgs"] = [
                {
                    "text":
                        "Configuration file missing: {}".format(conf_file)
                }
            ]
        else:
            item["failed"] = False

    # Finish tasks

    def _finish_workdir(self, item):
        """
        Remove student's working directory ~/SKU/lab_name
        """
        lab_name = type(self).__name__
        # Removing the ~/SKU/lab_name directory
        if not labtools.rmdir(lab_name, recursive=True):
            item["failed"] = True
            item["msgs"] = [{"text": "Directory could not be removed"}]
            return

        # Note: This section is commented out because we should not
        # remove the ~/SKU directory
        # # Remove the ~/SKU directory
        # try:
        #     shutil.rmtree(labtools.get_sku_path())
        # except OSError as e:
        #     item["failed"] = True
        #     item["msgs"] = [{"text": e}]
        # else:
        #     item["failed"] = False
