#
# Copyright 2021 Red Hat, Inc.
#
# NAME
#     features-users - DO480 Configure lab exercise script
#
# SYNOPSIS
#     features-users {start|finish}
#
#        start   - prepare the system for starting the lab
#        finish  - perform post-exercise cleanup steps
#
# CHANGELOG
#   * Tue Oct 26 2021 Alejandro Coma <acomabon@redhat.com>
#   - original code

"""
Lab script for DO480 Configure.
This module implements the start and finish functions for the
features-users guided exercise.
"""

from .common import steps
from labs.common.userinterface import Console
from labs.grading import Default as GuidedExercise

from .common.constants import USER_NAME, IDM_SERVER, OCP4_API, OCP4_MNG_API

labname = 'features-users'

class FeaturesUsers(GuidedExercise):
    """Activity class."""
    __LAB__ = labname

    def start(self):
        """
        Prepare systems for the lab exercise.
        """
        items = [
            steps.run_command(label="Verifying connectivity to OCP4 cluster", hosts=["workstation"], command="oc login", options="-u admin -p redhat " + OCP4_API, returns="0"),
            steps.run_command(label="Logging in to IDM", hosts=IDM_SERVER, command="echo 'Redhat123@!' | kinit admin", options="", returns="0"),
            steps.run_command(label="Creating user stage-admin", hosts=IDM_SERVER, command="echo 'redhat' | ipa user-add stage-admin --first=Stage --last=Admin --password", options="", returns="0"),
            steps.run_command(label="Creating user prod-admin", hosts=IDM_SERVER, command="echo 'redhat' | ipa user-add prod-admin --first=Production --last=Admin --password", options="", returns="0"),
            steps.run_command(label="Creating group production-administrators", hosts=IDM_SERVER, command="ipa group-add", options="production-administrators", returns="0"),
            steps.run_command(label="Creating group stage-administrators", hosts=IDM_SERVER, command="ipa group-add", options="stage-administrators", returns="0"),
            steps.run_command(label="Adding user prod-admin to group production-administrators", hosts=IDM_SERVER, command="ipa group-add-member", options="production-administrators --users=prod-admin", returns="0"),
            steps.run_command(label="Adding user stage-admin to group stage-administrators", hosts=IDM_SERVER, command="ipa group-add-member", options="stage-administrators --users=stage-admin", returns="0"),
            steps.run_command(label="Retrieving the IPA CA certificate", hosts=["workstation"], command="wget", options="http://idm.ocp4.example.com/ipa/config/ca.crt -O ca.crt", returns="0"),
            steps.run_command(label="Creating the LDAP password secret in RHOCP", hosts=["workstation"], command="oc", options="create secret generic ldap-secret --from-literal=bindPassword=Redhat123@! -n openshift-config", returns="0"),
            steps.run_command(label="Creating the CA config map in RHOCP", hosts=["workstation"], command="oc", options="create configmap ca-config-map --from-file=ca.crt=./ca.crt -n openshift-config", returns="0"),
            steps.run_command(label="Configuring OAuth in RHOCP", hosts=["workstation"], command="oc", options="apply -f ./files/oauth.yaml", returns="0"),
            steps.run_command(label="Creating user prod-admin in RHOCP", hosts=["workstation"], command="oc", options="login -u prod-admin -p redhat https://api.ocp4.example.com:6443", returns="0"),
            steps.run_command(label="Creating user stage-admin in RHOCP", hosts=["workstation"], command="oc", options="login -u stage-admin -p redhat https://api.ocp4.example.com:6443", returns="0"),
            steps.run_command(label="Logging out", hosts=["workstation"], command="oc", options="logout", returns="0")
        ]
        Console(items).run_items(action="Starting")

    def finish(self):
        """
        Perform any post-lab cleanup tasks.
        """
        items = [
            steps.run_command(label="Verifying connectivity to OCP4 cluster", hosts=["workstation"], command="oc login", options="-u admin -p redhat " + OCP4_API, returns="0"),
            steps.run_command(label="Logging in to IDM", hosts=IDM_SERVER, command="echo 'Redhat123@!' | kinit admin", options="", returns="0"),
            steps.run_command(label="Removing user stage-admin", hosts=IDM_SERVER, command="ipa user-del stage-admin", options="", returns="0"),
            steps.run_command(label="Removing user prod-admin", hosts=IDM_SERVER, command="ipa user-del prod-admin", options="", returns="0"),
            steps.run_command(label="Removing group production-administrators", hosts=IDM_SERVER, command="ipa group-del", options="production-administrators", returns="0"),
            steps.run_command(label="Removing group stage-administrators", hosts=IDM_SERVER, command="ipa group-del", options="stage-administrators", returns="0"),
            steps.run_command(label="Removing LDAP password secret", hosts=["workstation"], command="oc", options="delete secret ldap-secret -n openshift-config", returns="0"),
            steps.run_command(label="Removing CA config map", hosts=["workstation"], command="oc", options="delete configmap ca-config-map -n openshift-config", returns="0"),
            steps.run_command(label="Reverting OAuth config in RHOCP", hosts=["workstation"], command="oc", options="apply -f ./files/oauth-default.yaml", returns="0")
        ]
        Console(items).run_items(action="Finishing")
