# Lab Configuration Tool (in Python3)
#
# Chris Tusa <ctusa@redhat.com>
# (C)opyright 2020 : Red Hat, Inc. - see LICENSE
#

import yaml
import os
import tempfile


class ConfigError(BaseException):
    def __init__(self, message, object=None):
        self.message = message


def get_course_sku():
    """
    Return the SKU number of the course
    :return: unique course SKU
    """
    config = loadcfg()
    sku = config['rhtlab']['course']['sku']
    if sku is None:
        raise ConfigError("SKU is not configured")
    return sku


def loadcfg(filename='~/.grading/config.yaml'):
    """
    Load configuration data from a YAML file
    """
    filename = os.path.expanduser(filename)
    if os.path.exists(filename):
        # Open the config file and parse Yaml
        try:
            with open(filename) as f:
                cfgdata = yaml.load(f, Loader=yaml.FullLoader)
                if list(cfgdata)[0] == 'rhtlab':
                    return cfgdata
                else:
                    raise ConfigError(
                        "Invalid configuration file %s, invalid format"
                        % filename)
        except yaml.YAMLError as err:
            raise ConfigError("Invalid configuration file %s" % filename, err)
    else:
        raise ConfigError("Configuration file %s not found" % filename)


def savecfg(cfgdata, filename):
    """
    Saves the configuration to a yaml file.
    'cfgdata' should be passed in as a Python dictionary
    'filename' should be pre-validated through the passing function
    """
    filename = os.path.expanduser(filename)
    dir = os.path.split(filename)[0]
    if not os.path.exists(dir):
        os.mkdir(dir)
    with open(filename, "w") as cfgfile:
        yaml.dump(cfgdata, cfgfile)
        cfgfile.close()


def setsku(sku, filename='~/.grading/config.yaml'):

    try:
        cfgdata = loadcfg(filename)
        cfgdata['rhtlab']['course']['sku'] = sku.lower()
        savecfg(cfgdata, filename)
    except ConfigError:
        gencfg(sku=sku)


def gencfg(filename='~/.grading/config.yaml', sku=None,
           force=False):
    """
    Create a default configuration file
    """
    filename = os.path.expanduser(filename)
    if os.path.exists(filename) and not force:
        raise ConfigError("Configuration file exists %s" % filename)

    cfgdata = {'rhtlab':
               {
                 'course':
                 {
                   'sku': sku.lower()
                 },
                 'logging':
                 {
                   'path': get_default_log_path(),
                   'level': 'error'
                 }
                }
               }

    savecfg(cfgdata, filename)

    return cfgdata


def get_default_log_path():
    return os.path.join(
        tempfile.gettempdir(),
        "log",
        "labs",
        ""
    )


def get_version_lock(filename='/etc/rht'):
    if os.path.exists(filename):
        with open(filename, 'r') as reader:
            line = reader.readline()
            while line != '':
                var = line.split('"')
                if var[0] == "RHT_VERSION_LOCK=":
                    print("Version lock is %s" % var[1])
                    return var[1]
                line = reader.readline()
    return None
