import pkg_resources
import os
from labs.common import playbooks, userinterface


class Default:
    def __init__(self):
        pass

    def finish(self):
        print('The finish command is not supported for this lab.')

    def grade(self):
        print('The grade command is not supported for this lab.')

    def start(self):
        print('The start command is not supported for this lab.')

    def run_playbook(self, item):
        """Execute the playbook.

        The name of the playbook file must be provided in ``item["playbook"]``
        or the path to the playbook in ``item["playbookPath"]``.
        """
        if "playbookPath" in item:
            playbook_path = item["playbookPath"]
        else:
            playbook_path = self.find_playbook(item["playbook"])

        runner = playbooks.Runner(playbook_path)
        if "vars" in item:
            messages = runner.run(vars=item["vars"])
        else:
            messages = runner.run()
        if messages:
            item["failed"] = True
            item["msgs"] = [{"text": "Playbook failed: "
                            + os.path.basename(playbook_path)}]
            for msg in messages:
                item["msgs"].append({"text": msg})
        else:
            item["failed"] = False

    def find_playbook(self, playbook, fixed=False):
        """
        Find the playbook in a standard location.
        """
        if fixed:
            class_module = self.__module__.split(".")[1]
            playbook = "ansible/" + class_module + "/" + playbook

        playbook_path =\
            pkg_resources.resource_filename(self.__module__,
                                            playbook)

        return playbook_path


class AutoPlay(Default):
    def __init__(self):
        pass

    def start(self):
        """
        Automatically locate the start playbook, if one exists,
        and run it.
        """
        playbook_path = self.find_playbook("start.yml", fixed=True)
        if not os.path.exists(playbook_path):
            super().start()
            return

        items = [
            {
                "label": "Running Start Playbook",
                "task": self.run_playbook,
                "playbookPath": playbook_path,
            },
        ]
        userinterface.Console(items).run_items()

    def grade(self):
        """
        Automatically locate the grade playbook, if one exists,
        and run it.
        """
        playbook_path = self.find_playbook("grade.yml", fixed=True)
        if not os.path.exists(playbook_path):
            super().grade()
            return

        items = [
            {
                "label": "Running Grade Playbook",
                "task": self.run_playbook,
                "playbookPath": playbook_path,
            },
        ]
        ui = userinterface.Console(items)
        ui.run_items(action="Grading")
        ui.report_grade()

    def finish(self):
        """
        Automatically locate the finish playbook, if one exists,
        and run it.
        """
        playbook_path = self.find_playbook("finish.yml", fixed=True)
        if not os.path.exists(playbook_path):
            super().finish()
            return

        items = [
            {
                "label": "Running Finish Playbook",
                "task": self.run_playbook,
                "playbookPath": playbook_path,
            },
        ]
        userinterface.Console(items).run_items(action="Finishing")
