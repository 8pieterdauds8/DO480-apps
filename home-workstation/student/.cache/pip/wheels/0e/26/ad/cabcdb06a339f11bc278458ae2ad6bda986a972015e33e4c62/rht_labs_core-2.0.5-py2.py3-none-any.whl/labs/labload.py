# Lab Dynamic Loading
#
# Jim Rigsbee <jrigsbee@redhat.com>
# (C)opyright 2021 : Red Hat, Inc. - see LICENSE
#
import os
import pkgutil
import inspect
import importlib

from labs.grading import Default
from labs.laberrors import LabError
from labs.lablog import lablog_init
from labs import labconfig


def loadcache():
    course = labconfig.get_course_sku()
    cache = {}
    try:
        module = importlib.import_module(course)
        modules = [name for _, name, _
                   in pkgutil.iter_modules([os.path.dirname(module.__file__)])]
        if len(modules) == 0:
            return cache
        for m in modules:
            s = importlib.import_module(course + '.' + m)
            c = [obj for _, obj in inspect.getmembers(s, inspect.isclass)]
            for x in c:
                if x.__name__ != 'Default' and x.__name__ != 'AutoPlay'\
                   and Default in inspect.getmro(x):
                    script = x.__name__
                    if "__LAB__" in x.__dict__.keys():
                        script = x.__LAB__
                    entry = {
                        "class": x.__name__,
                        "module": m
                    }
                    cache[script] = entry
    except ModuleNotFoundError:
        if 'm' in locals():
            print("Could not find module %s for course %s"
                  % (m, course))
        else:
            print("Could not find modules for course %s" % course)
        return {}
    return cache


def get_classes(ctx, args, incomplete):
    cache = loadcache()
    classes = [script for script in cache.keys() if incomplete in script]
    return classes


def is_course_installed(sku):
    try:
        importlib.import_module(sku.lower())
        return True
    except ModuleNotFoundError:
        return False


def import_grading_library(config, name):
    """
    Imports the grading library. Takes a single parameter
    :param name:
    :return:
    """
    cache = loadcache()
    course = labconfig.get_course_sku()
    if name not in cache.keys():
        raise LabError("Script %s not in course library %s" % (name, course))
    cache_entry = cache[name]
    try:
        lablog_init(config, cache_entry["module"])
        module = importlib.import_module(course + "." + cache_entry["module"])
        class_ = getattr(module, cache_entry["class"])
        return class_()
    except ModuleNotFoundError:
        raise LabError("Script %s in course library %s or one of its "
                       "components was not found."
                       % (name, course))
