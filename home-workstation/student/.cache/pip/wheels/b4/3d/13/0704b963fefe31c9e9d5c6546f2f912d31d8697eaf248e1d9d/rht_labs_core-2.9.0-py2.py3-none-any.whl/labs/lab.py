#!/usr/bin/env python3
#
# This is the main entry point for the lab grading framework.
# Execute lab --help for syntax on using this script.
#

import io
import os
import subprocess
import sys
from contextlib import redirect_stdout

import click
import labs.version as ver
from labs import labconfig, labload
from labs.common.info.system import create_report_from_strategy
from labs.environment import get_pypi_url
from labs.laberrors import LabError


def setup_for_command_execution():
    """
    Loads the config before command execution.

    """
    try:
        config = labconfig.loadcfg()
        return config
    except labconfig.ConfigError as error:
        show_load_help_and_exit(error)


def show_load_help_and_exit(error):
    click.secho(error.message, fg='red')
    example = click.style('lab select SKU', bold=True)
    click.echo(
        "Use %s to load the grading library" % example)
    exit(1)


def _execute_pip_install(sku, version, env, upgrade=False):
    """Extras common code that is used to either install or upgrade
    a course dynolabs package.

    Args:
        sku (str): The course SKU
        version ([type]): [description]
        env (str): either "test" or "prod", to describe the environment for
                   installed packages.
        upgrade (bool, optional): If True, performs a `pip upgrade`.
                   Defaults to False.

    Returns:
        str: The name of the installed/upgraded package
    """
    index_url = get_pypi_url(env)
    lock_version = labconfig.get_version_lock()
    if version is None and lock_version is None:
        package = 'rht-labs-' + sku.lower()
    else:
        if version is None and lock_version:
            package = '"rht-labs-' + sku.lower() + lock_version + '"'
        else:
            package = 'rht-labs-' + sku.lower() + '==' + str(version)

    upgrade_option = ""
    if upgrade:
        upgrade_option = " --upgrade"

    pre_packages_option = ""
    if env == "test":
        # Allow pre-release packages for a test environment.
        pre_packages_option = " --pre"

    cmd = (
        f"{sys.executable} -m pip install -qqq --no-cache-dir"
        f"{upgrade_option}{pre_packages_option}"
        f" --extra-index-url {index_url} {package}"
    )

    subprocess.check_call(cmd, shell=True)

    return package


@click.command()
@click.argument("sku", required=True)
@click.option("--force", "-f", is_flag=True,
              help="Set course library even if it is "
              "not installed (mainly for course developers).")
def select(sku, force):
    """
    Select the active course grading library.

    SKU is the course code, such as gl006
    """
    if force or labload.is_course_installed(sku):
        labconfig.setsku(sku)
    else:
        click.echo("Course %s grading library is not installed." % sku)


@click.command()
@click.argument("sku", required=True)
@click.option("--version", help="Version of the course package to load."
              " If not specified, it will default to the latest version."
              " Version is like 1.0.3")
@click.option("--uninstall", "-u", is_flag=True,
              help="Uninstall the course library before installing new one.")
@click.option("--env", default='prod', type=click.Choice(['prod', 'test']),
              help="Load grading modules from this environment."
              " This is used normally by course developers."
              " Defaults to prod.")
def install(sku, version, uninstall, env):
    """
    Install the course library.

    SKU is the course code, such as gl006
    """

    # Uninstall library with pip
    if uninstall:
        try:
            subprocess.check_call([sys.executable, '-m', 'pip', 'uninstall',
                                  '-y', '-q', 'rht-labs-' + sku.lower()])
        except subprocess.CalledProcessError:
            pass
    # Install library with pip and version specified from proper env
    try:
        package = _execute_pip_install(sku, version, env, upgrade=False)
        print("Installed %s." % package)
        labconfig.setsku(sku.lower())
    except subprocess.CalledProcessError:
        print("Could not install course library %s as requested." % package)


@click.command()
@click.argument("sku", required=True)
@click.option("--version", help="Version of the course package to upgrade to."
              " If not specified, it will default to the latest version."
              " Version is like 1.0.3")
@click.option("--env", default='prod', type=click.Choice(['prod', 'test']),
              help="Load grading modules from this environment."
              " This is used normally by course developers."
              " Defaults to prod.")
def upgrade(sku, version, env):
    """
    Upgrade the course library.

    SKU is the course code, such as gl006
    """

    # Upgrade library with pip and version specified from proper env
    try:
        package = _execute_pip_install(sku, version, env, upgrade=True)
        print("Upgraded %s." % package)
        labconfig.setsku(sku.lower())
    except subprocess.CalledProcessError:
        print("Could not install course library %s as requested." % package)


@click.group(name='lab', invoke_without_command=True)
@click.pass_context
@click.option('--version', '-v', is_flag=True,
              help='Get lab framework version number and exit.')
def main(ctx, version):
    """
    CLI for Red Hat Training lab grading.
    """

    if version:
        print('Lab framework version %s' % ver.__version__)
        sys.exit(0)

    if ctx.invoked_subcommand is None:
        print("No grading command specified.")


def _main(command, script):
    switch = {
        'start': _start,
        'finish': _finish,
        'grade': _grade
    }
    proc = switch.get(command, "error")
    if proc == "error":
        raise LabError("Invalid command %s" % command)
    stdout = io.StringIO()
    with redirect_stdout(stdout):
        proc(script)
    return stdout.getvalue()


@click.command()
@click.argument('script', type=click.STRING,
                autocompletion=labload.get_classes)
def finish(script):
    """
    Finish the lab session.

    SCRIPT is the name of the lab script.
    This variable supports tab completion.
    """
    try:
        _finish(script)
    except LabError as le:
        print(le)


def _finish(script):
    """
    Finish the lab session.
    """
    config = setup_for_command_execution()
    grading = labload.import_grading_library(config, script)
    grading.finish()


@click.command()
@click.argument('script', type=click.STRING,
                autocompletion=labload.get_classes)
def grade(script):
    """
    Grade the lab.

    SCRIPT is the name of the lab script.
    This variable supports tab completion.
    """
    try:
        _grade(script)
    except LabError as le:
        print(le)


def _grade(script):
    """
    Grade the lab.
    """
    config = setup_for_command_execution()
    grading = labload.import_grading_library(config, script)
    grading.grade()


@click.command()
@click.argument('script', type=click.STRING,
                autocompletion=labload.get_classes)
def start(script):
    """
    Start the lab session.

    SCRIPT is the name of the lab script.
    This variable supports tab completion.
    """
    try:
        _start(script)
    except LabError as le:
        print(le)


def _start(script):
    """
    Start the lab session.
    """
    config = setup_for_command_execution()
    grading = labload.import_grading_library(config, script)
    grading.start()


@click.command()
@click.argument("shell", required=False, default="bash",
                type=click.Choice(["bash", "zsh", "fish"]))
def completion(shell):
    """
    Print completion commands for a given shell
    """
    try:
        # Get the name of the current script: "lab"
        name = os.path.splitext(os.path.basename(__file__))[0]

        # Run "_LAB_COMPLETE=source_<shell> lab" and print the result
        env = os.environ.copy()
        env["_{}_COMPLETE".format(name.upper())] = "source_{}".format(shell)
        subprocess.run(
            [name],
            timeout=1,
            env=env,
            check=False,
            stdin=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception as e:
        print(e)


@click.command(name='system-info')
def system_info():
    """
     Generates and sends a system report of the current environment.
    """
    env_report = create_report_from_strategy('print')
    env_report.send()


main.add_command(finish)
main.add_command(grade)
main.add_command(start)
main.add_command(select)
main.add_command(install)
main.add_command(upgrade)
main.add_command(completion)
main.add_command(system_info)

if __name__ == "__main__":
    main()
