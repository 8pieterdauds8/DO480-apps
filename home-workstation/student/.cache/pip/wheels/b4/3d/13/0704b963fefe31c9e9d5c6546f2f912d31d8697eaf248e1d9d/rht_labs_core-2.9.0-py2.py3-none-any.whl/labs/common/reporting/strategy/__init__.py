from abc import ABC, abstractmethod


class ReportingStrategyNotFoundException(Exception):
    pass


class ReportingStrategy(ABC):
    @abstractmethod
    def send(self, report) -> None:
        raise NotImplementedError
