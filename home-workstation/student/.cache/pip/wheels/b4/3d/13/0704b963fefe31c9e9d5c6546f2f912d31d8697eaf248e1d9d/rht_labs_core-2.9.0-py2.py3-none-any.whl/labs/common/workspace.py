
import os
from pathlib import Path
from typing import Union
from labs.common.config import ClassroomConfigFile
from labs.common.labtools import copy_or_replace_dir
from labs.common.userinterface import echo


class Workspace:

    """
    A "Workspace" instance is an abstraction of the config and
    the working directory that the student will use to
    perform the labs in a course

    This class configures the classroom env variables,
    creates a working directory
    and exposes utility workspace functions
    """

    config: ClassroomConfigFile

    def __init__(self, config: ClassroomConfigFile = None):
        if config:
            self.config = config
            self.config.load()

    def configure(self, config: ClassroomConfigFile, output: bool = True):
        """
        Creates the workspace directory and configuration file
        """
        self.config = config
        self.config.save(output)
        self.create_workdir(output)
        return self

    def create_workdir(self, output: bool = True):
        """
        Creates the workspace directory if it does not exist
        """
        try:
            os.mkdir(self.config.workdir)
            if output:
                echo(f"Directory {self.config.workdir} created")
        except FileExistsError:
            if output:
                echo(f"Directory {self.config.workdir} already exists")

    def exists(self):
        """
        Checks if the workspace directory exists
        """
        workdir = self.config.workdir
        return workdir and os.path.isdir(workdir)

    def is_current_directory(self):
        """
        Checks if the current working directory is the workspace
        """
        cwd = os.path.abspath(os.getcwd())
        return os.path.abspath(self.config.workdir) == cwd

    def path(self, dir: str):
        """
        Returns the absolute path of a specific directory within the workspace
        """
        workdir = self.config.workdir or ""
        return os.path.join(workdir, dir)

    def copy_subdir(self,
                    relative_source: Union[Path, str],
                    relative_destination: Union[Path, str]):
        """
        Copy directories inside the workspace
        Directory paths are relative to the workspace path
        """

        source = self.path(relative_source)
        destination = self.path(relative_destination)

        copy_or_replace_dir(source, destination)
