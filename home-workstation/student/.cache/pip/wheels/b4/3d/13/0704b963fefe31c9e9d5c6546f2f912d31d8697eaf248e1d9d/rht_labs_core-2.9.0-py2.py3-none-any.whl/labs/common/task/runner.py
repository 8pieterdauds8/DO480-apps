import logging
from typing import Any, Dict


Item = Dict[str, Any]


def run_task(item: Item):
    """
    Run an item task
    """
    ret_code = 0

    logging.info(f"[Task running] Item: {item}")

    try:
        ret_code = item["task"](item)
    except Exception as e:
        logging.exception("Unexpected error")
        item["failed"] = True
        item["msgs"] = item.get("msgs", []) + [
            {"text": f"An unexpected error ocurred: {e}"},
            {"text": "Check the log file for more details"}
        ]

    logging.info(f"[Task completed] Code: {ret_code}, Item: {item}")

    return ret_code
