#
# Copyright (c) 2020 Red Hat Training <training@redhat.com>
#
# All rights reserved.
# No warranty, explicit or implied, provided.
#

"""Display progress and status of the lab module executions."""

import logging
import time
import threading
from click import echo, style, get_terminal_size

from labs.common.task.runner import run_task


class Spinner:
    """Display an animated spinner.

    :param spin_chars: Characters composing the spinner animation.
                       By defaut: ["|", "/", "-", "\\"]
    :type spin_chars: dict
    :param delay: Animation speed. This is the time (in seconds) to wait
                  between each animation frame. Defaults to one second.
    :type delay: int
    """

    def __init__(self, spin_chars=["|", "/", "-", "\\"], delay=1):
        """Initialize the object."""
        self.spin_chars = spin_chars
        self.delay = delay
        self.spin_chars_index = 0
        self.spin_chars_len = len(spin_chars)

    def _spinner_loop(self):
        """Animate the spinner.

        This method is executed in a dedicated thread.
        """
        # The thread runs as long as self.stop_please is False.
        # self.stop_please is set to True by the __exit__ method.
        while not self.stop_please:
            echo(self.spin_chars[self.spin_chars_index], nl=False)
            self.spin_chars_index = (self.spin_chars_index + 1)\
                % self.spin_chars_len
            time.sleep(self.delay)
            # Erase the character
            echo("\b", nl=False)
        echo(" \b", nl=False)

    def __enter__(self):
        """Start the animation."""
        self.stop_please = False
        self.thread = threading.Thread(target=self._spinner_loop)
        self.thread.start()

    def __exit__(self, exc_type, exc_value, traceback):
        """Stop the animation."""
        self.stop_please = True
        self.thread.join()


class Console:
    """Format messages.

    :param separator: Fill character. "." by default.
    :type separator: char
    :param bullet1: Bullet point to add in front of the message.
                    " · " by default.
    :type bullet1: str
    :param bullet2: Bullet point for error messages. " - " by default.
    :type bullet2: str
    :param columns: Line length. If set to 0, the default, the current screen
                    width is used.
    :type columns: int
    :param status_length: Max lenght of the status string. Those strings are
                          the one that are added at the end of the lines (FAIL,
                          SUCCESS, ...) Default: 10
    :type status_length: int
    :param spinner_delay: Seconds to wait for the execution of each task.
                          1 second by default
    :type  spinner_delay: int
    """

    def __init__(
        self, items, separator=".", bullet1=" · ",
        bullet2=" - ", columns=0, status_length=10,
        spinner_delay=1
    ):
        """Initialize the object."""
        self.separator = separator
        self.bullet1 = bullet1
        self.bullet1_length = len(bullet1)
        self.bullet2 = bullet2
        self.status_length = status_length
        self.spinner_delay = spinner_delay
        if columns:
            self.columns = columns
        else:
            self.columns = get_terminal_size()[0]
        self.items = items

    def get_padded_message(self, message):
        """Return the formated message.

        :param message: Message to format
        :type message: str

        :returns: The formated message (with a bullet in front and the fill
                  characters at the end)
        """
        msg = self.bullet1 + message + " "
        max_len = self.columns - self.status_length - 1
        res = ""
        # If the message is too long, split it in lines
        while len(msg) > max_len:
            s = msg[:max_len]
            i = s.rfind(" ")
            # Stop if space not found or if found in the leading spaces
            if i < self.bullet1_length:
                break

            res += msg[:i] + "\n"
            msg = " " * self.bullet1_length + msg[i + 1:]

        res += msg.ljust(max_len + 1, self.separator) + " "
        return res

    def get_secondary_message(self, message):
        """Return the formated message for second level.

        :param message: Message to format
        :type message: str

        :returns: The formated message (with a bullet in front)
        """
        return " " * self.bullet1_length + self.bullet2 + message

    def run_items(self, action="Starting"):  # noqa: C901
        """
        Process each item in the given list.
        Each item in the list is a dictionary. The function uses the following
        keys:

        "task": Function to execute. If None or not set, nothing is executed.
                That function is called with the item dictionary as parameter.
                If the function returns True (the truth), then the execution
                stops immediately and the other following task in the list are
                not run.
        "failed": The function defined in "task" can set this key. If False,
                then the success status is reported. If True, then a failed
                status is reported to students. In addition, if the "msgs" key
                is also set, those messages are also displayed to provide more
                details on the failure.
        "msgs": List of additional error messages when the task failed. Each
                element of that list is a dictionary with the key set to
                "text" and the message as the value.
        "grading": Boolean flag to indicate if the executed item is for grading
                purposes. If defined and True, then a 'PASS' string is echoed
                in blue. In other cases, a 'SUCCESS' string is echoed in green.

        :param items: List of item to process.
        :type items: list
        """
        echo("\n%s lab.\n" % action)
        for item in self.items:
            condition = item.get("condition", lambda: True)
            if not condition():
                logging.debug(f"{item} was skipped due to false condition")
                continue
            if "header" in item:
                echo()
                echo(item["header"])
                echo()
                continue
            echo(self.get_padded_message(item["label"]), nl=False)
            ret_code = 0
            if "task" in item and item["task"]:
                with Spinner(delay=self.spinner_delay):
                    if item["task"] is not None:
                        ret_code = run_task(item)
            failed = False
            if ("failed" in item and item["failed"]) or ret_code:
                echo(style("FAIL", fg="red"))
                failed = True
            else:
                if item.get("grading"):
                    echo(style("PASS", fg="blue"))
                else:
                    echo(style("SUCCESS", fg="green"))
            if "msgs" in item:
                for msg in item["msgs"]:
                    if "text" in msg:
                        echo(self.get_secondary_message(msg["text"]))
            if failed and "fatal" in item and item["fatal"]:
                echo(self.get_secondary_message("Cannot continue %s lab") %
                     action.lower())
                break
        echo("")

    def report_grade(self):
        for item in self.items:
            if "failed" in item and item["failed"]:
                status = style("FAIL", fg='red')
                break
        else:
            status = style("PASS", fg='green')
        echo(f"Overall lab grade: {status}\n")
