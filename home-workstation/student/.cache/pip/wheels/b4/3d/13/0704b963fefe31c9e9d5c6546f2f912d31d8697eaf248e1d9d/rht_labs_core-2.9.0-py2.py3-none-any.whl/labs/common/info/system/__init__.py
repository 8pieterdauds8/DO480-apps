from labs.common.info.system.systeminfo import SystemInfo
from labs.common.reporting.strategy import ReportingStrategyNotFoundException
from labs.common.reporting.strategy.print import PrintReportingStrategy


def create_report_from_strategy(name: str) -> SystemInfo:
    if 'print' == name:
        return SystemInfo(PrintReportingStrategy())

    raise ReportingStrategyNotFoundException
