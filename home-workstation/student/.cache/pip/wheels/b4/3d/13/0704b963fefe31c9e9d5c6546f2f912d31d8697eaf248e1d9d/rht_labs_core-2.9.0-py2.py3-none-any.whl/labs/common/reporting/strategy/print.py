from json import dumps
from typing import Dict

from . import ReportingStrategy


class PrintReportingStrategy(ReportingStrategy):
    def send(self, report: Dict) -> None:
        print(dumps(report, sort_keys=True, indent=4))
