"""
Common lab steps
"""

from . import tasks


def run_command(label, hosts, command, returns=0, options=None, prints='',
                fatal=False, student_msg='', sshkey='', shell=False,
                condition=None):
    if options is None:
        options = []
    if condition is None:
        def default_condition():
            return True
        condition = default_condition
    return {
                "label": label,
                "task": tasks.run_command,
                "hosts": hosts,
                "username": "root",
                "password": "redhat",
                "command": command,
                "returns": returns,
                "options": options,
                "prints": prints,
                "fatal": fatal,
                "student_msg": student_msg,
                "sshkey": sshkey,
                "shell": shell,
                "condition": condition,
    }


def header(header):
    return {
        "header": header
    }
