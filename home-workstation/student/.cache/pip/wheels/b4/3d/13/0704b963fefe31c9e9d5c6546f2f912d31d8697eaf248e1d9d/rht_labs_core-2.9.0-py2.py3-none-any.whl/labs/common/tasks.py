"""
Common reusable tasks.
"""
from abc import ABC
import shlex
import subprocess
from functools import wraps
from typing import Dict, Iterable, List, Tuple, Callable, Any, Union
from . import labtools
from . import labcommand
from .workspace import Workspace
try:
    from .git import config as gitconfig
    from .git import repository
except ModuleNotFoundError:
    # Git is an optional dependency
    pass


# Define the type of a task
Task = Callable[[Dict], Any]


def check_workspace_exists(item: Dict):
    workspace: Workspace = item["workspace"]
    item["failed"] = not workspace.exists()


def mkdir(item: Dict):
    """
    Creates a folder

    :param item: dict containing: path
    """
    path: str = item["path"]

    result = labtools.mkdir(path)
    item.update(result)


def rmdir(item: Dict):
    """
    Removes a folder

    :param item: dict containing:path
    """
    path: str = item["path"]

    result = labtools.rmdir(path)
    item.update(result)


def check_git_config(item: Dict):
    """
    Checks if the user and the email are set in the git global config
    """

    item["failed"] = False
    item["msgs"] = []

    if not gitconfig.username():
        item["failed"] = True
        item["msgs"].append(
            {"text": "user.name not set"}
        )
    if not gitconfig.email():
        item["failed"] = True
        item["msgs"].append(
            {"text": "user.email not set"}
        )


def check_git_remote_points_to(item: Dict):
    """
    Checks whether a local repository has a remote url
    that points to remote_repo_name

    :param item: Dict containing
        repopath: absolute path of the local repository
        remote_repo_name: name of the remote repository.
            This function checks if the remoteURL includes this value
        name: name of the remote (optional)

        """
    repopath: str = item["repopath"]
    remote_repo_name: str = item["remote_repo_name"]
    name: str = item.get("name", "origin")

    tail = f"{remote_repo_name}.git"
    item["failed"] = True
    item["msgs"] = [
        {"text": f"{tail} not found in remote urls"}
    ]

    urls = []
    try:
        urls = repository.get_remote_urls(repopath, name)
    except Exception:
        urls = []

    for url in urls:
        if url.endswith(tail):
            item["failed"] = False
            item["msgs"] = []


def check_git_local_repo_exists(item):
    """
    Checks if a repository exists in a given local folder

    :param item: Dict containing
        repopath: name of the local repo folder
    """
    repopath: str = item["repopath"]

    if repository.exists(repopath):
        item["failed"] = False
        item["msgs"] = []
    else:
        item["failed"] = True
        item["msgs"] = [
            {"text": f"Repository does not exist at {repopath}"}
        ]


def grep(item):

    """
    Greps for content in a file, optionally ignoring cases.
    Fails if the content is not found

    :param item: Dict containing
        filepath
        content
        ignorecase (optional): False by default
    """

    filepath: str = item["filepath"]
    content: str = item["content"]
    ignorecase: bool = item.get("ignorecase", False)

    try:
        with open(filepath) as f:
            text = f.read()
            needle = content

            if ignorecase:
                text = text.lower()
                needle = content.lower()

            if needle in text:
                item["failed"] = False
            else:
                item["failed"] = True
                item["msgs"] = [{
                    "text": (f"{filepath} does not contain "
                                f"the following expected content: {content}")
                }]
    except OSError as error:
        item["failed"] = True
        item["msgs"] = [{
            "text": str(error)
        }]


def git(item: Dict):
    """
    Runs git commands

    :param item: Dict containing
        command: the git command as a list
        repopath
    """

    command: Iterable[str] = item.get("command", [])
    repopath: str = item["repopath"]

    try:
        repository.run(command[0], *command[1:], repodir=repopath)
        item["failed"] = False
    except repository.GitRepoError as error:
        # User tried to commit when there were no changes
        if "nothing to commit, working tree clean" in str(error).lower():
            item["failed"] = False
            item["msgs"] = [{
                "text": "Nothing to commit, skipping"
            }]
            return
        item["failed"] = True
        item["msgs"] = [{
            "text": str(error)
        }]


def check_command_result(item: Dict):
    """
    Runs a command and verifies its output and return code.

    :param item: Dict containing
        command: the git command
        cwd
        prints: Search this text in the output
        err_message: Message to use in case of error
        returns: Expected exit code
    """

    command: Tuple = item["command"]
    cwd: str = item.get("cwd")
    prints: str = item.get("prints")
    returns: str = item.get("returns")
    err_message: str = item.get("err_message")

    try:
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=cwd)
    except FileNotFoundError as err:
        item["failed"] = True
        item["msgs"] = [
            {"text": str(err)}
        ]
        return item

    stdout, stderr = process.communicate()

    try:
        if returns:
            assert returns == process.returncode, (
                f"Command did not exit with the {returns} code")

        if prints:
            assert prints in str(stdout), (
                f"'{prints}' not found in the command output")

        item["failed"] = False
    except AssertionError as err:
        item["failed"] = True
        item["msgs"] = []
        if err_message:
            item["msgs"].append({"text": err_message})

        item["msgs"].append({"text": str(err)})

        if stderr:
            item["msgs"].append({"text": f"Stderr: {stderr}"})


"""
@task decorator definition below

A function decorated with @task defines its signature
using regular Python parameters, instead of a dict.

This is to avoid errors caused by wrong dictionaries,
and to take advantage of intellisense and Python type hints.

Instead of defining a lab step like...

    {
        "label": "Step 1",
        "task": mytask
        "arg1": ...
        "arg2": ...
    }

...we define it as:

    {
        "label": "Step 1",
        "task": mytask(arg1, arg2)
    }

"""


class TaskException(Exception):
    msgs = []

    def __init__(self, msgs: Union[str, List[str]]):
        if isinstance(msgs, str):
            self.msgs = [msgs]
        else:
            self.msgs = msgs

        self.msgs = [{"text": msg} for msg in self.msgs]


class TaskResult(ABC):

    """
    Each task funcion should return an instance
    of this ABC (Abstract base class)
    """

    ok: bool
    msgs: List[str]

    def __init__(self, ok: bool, msgs: List[str] = None):
        self.ok = ok
        self.msgs = msgs or []

    def msgs_as_dicts(self):
        return [{"text": msg} for msg in self.msgs]


class TaskSuccess(TaskResult):

    def __init__(self, msgs: List[str] = None):
        return super().__init__(True, msgs)

    def __bool__(self):
        return True


class TaskFailure(TaskResult):

    def __init__(self, msgs: List[str] = None):
        return super().__init__(False, msgs)

    def __bool__(self):
        return False


TaskReturnValue = Union[TaskResult, bool, None]


def task(func: Callable[..., TaskReturnValue]):

    """
    This decorator wraps the call to the original function
    by accepting an "item" dictionary
    """

    @wraps(func)
    def wrapper(*args, **kwargs):

        def task(item: Dict):
            """
            This is the task function executed by DynoLabs, as:
                item["task"](item)
            """

            try:
                result = func(*args, **kwargs)

                # If the function returns False, raise error
                if result is False:
                    raise TaskException()

                # If the function returns an instance of TaskResult
                # we parse the status and the msgs
                if isinstance(result, TaskResult):
                    item["msgs"] = result.msgs
                    if result.ok:
                        item["msgs"] = result.msgs_as_dicts()
                    else:
                        raise TaskException(result.msgs)

                # Otherwise, consider the function result sucessful
                # (as long as the function does not raise a TaskException)

            except TaskException as error:
                item["failed"] = True
                if "msgs" not in item:
                    item["msgs"] = []
                for m in error.msgs:
                    item["msgs"].append(m)

        return task

    return wrapper


def run_command(item: Dict):
    """
    Run a command on target host(s).

    The following parameters are used:
    * ``command`` is a string with the command to be run. If the shell option
      is set to True, this string can be used to also add parameters or pipes.
    * (optional) ``options`` allows the user to add options to the command
      to be run by using an array.
    * ``host`` is the list of hosts where the command should be run
    * (optional) ``prints`` allows the user to look for a specific string at
      the stdout
    * (optional) ``returns`` allows the user to look for a specific return code
      at the output of the command
    When running in remote servers, the following parameters are used:
    * ``username`` username to execute the remote command
    * ``password`` password to authenticate the remote user
    * (optional) ``sshkey`` is the used for the ssh connection.
      Defaults to /home/student/.ssh/lab_rsa if not provided.
    * (optional) ``student_msg`` allows to provide more information to the
      students when the command exit is an error.
    * (optional) ``shell`` allows to set the subprocess shell option to true,
      executing the command through the shell. Then, the command, options,
      pipes, etc. can be given through the command option.
    """

    sshkey = labcommand.check_sshkey(item)

    host_list: str = item["hosts"]

    command = item["command"]
    options = item["options"]

    shell_opt = item["shell"]
    # Note: to test that the shell parameter works correctly, I recommend using
    # a lab script that contains the following:
    #
    # steps.run_command("label", ["workstation", "servera", "serverb"],
    #                   command="echo", options=["'"]),
    #
    # This command runs with shell=False, so the ' should be properly escaped.
    # The output of running this should be a single '.
    #
    # steps.run_command("label", ["workstation", "servera", "serverb"],
    #                   command="cat /etc/passwd | grep nobody ; uptime",
    #                   shell=True),
    #
    # This command runs with shell=True, so pipes and ; should work correctly.
    # It should output something like:
    #
    # nobody:x:65534:65534:Kernel Overflow User:/:/sbin/nologin
    #  06:06:37 up 35 min,  1 user,  load average: 0.00, 0.00, 0.00
    #
    # Remember to test both local and remote commands.

    args = [command] + options

    output = []
    item["failed"] = False

    for target in host_list:
        target_args = args
        target_shell_opt = shell_opt
        # If running in remote server use ssh
        if (target != "localhost") and (target != "workstation"):
            user = item["username"]
            target_shell_opt = False
            if shell_opt:
                target_args = ["ssh", f"{user}@{target}", "-i", sshkey] + args
            else:
                quoted_args = list(map(shlex.quote, args))
                target_args = (
                    ["ssh", f"{user}@{target}", "-i", sshkey] +
                    quoted_args
                )

        output = labcommand.run_log(target_args,
                                    stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE,
                                    shell=target_shell_opt)

        if "prints" in item:
            labcommand.check_retcode(item, output)
        if "prints" in item:
            labcommand.check_prints(item, output)

        if item["failed"] is True:
            labcommand.log_errormsg(item["msgs"])
