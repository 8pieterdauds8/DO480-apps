import json
from pathlib import Path
from abc import ABC, abstractmethod
from .userinterface import echo


class ClassroomConfigFile(ABC):

    """
    Abstract classroom config file.
    """

    filepath: str
    workdir: str

    def __init__(self, filepath: str, workdir: str):
        """
        :param filepath: Absolute path of the file where the config is stored
        :param workdir: Absolute path of the lab working dir
        """
        self.filepath = filepath
        self.workdir = workdir

    @abstractmethod
    def load(self) -> "ClassroomConfigFile":
        pass

    @abstractmethod
    def save(self, output: bool = True):
        pass


class ClassroomConfigJsonFile(ClassroomConfigFile):

    """
    Classroom config as a JSON file
    """

    def load(self) -> "ClassroomConfigJsonFile":
        """
        Reads the config from a JSON file
        """
        try:
            with open(self.filepath) as configfile:
                items = json.load(configfile)
                self.__dict__.update(items)
        except (FileNotFoundError, json.decoder.JSONDecodeError):
            pass

        return self

    def save(self, output: bool = True):
        """
        Saves the dictionary as a JSON file
        """
        with open(self.filepath, 'w') as outfile:
            json.dump(self.__dict__, outfile, indent=2)

        if output:
            echo(f"Saved configuration in {self.filepath}")


def default_config_path(filename: str):
    """
    Returns a default config file path in ~/.grading/, given a filename
    """
    return Path.home().joinpath(".grading").joinpath(filename)
