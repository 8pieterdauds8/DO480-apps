Role Name
=========

When "mode: add", this role configures the internal image registry to use storage provided by OpenShift Containter Storage.
When "mode: remove", this role reverts the internal image registry to use the default storage class provided by the classroom environment (nfs-storage).

Courses using this role:
  - DO370

Requirements
------------

In order to use Ansible to manage Kubernetes, this role requires RPMs that are not available from the typical repositories.
- The lab grading framework installs the package dependencies in a virtual environment using pip.

Role Variables
--------------

    registry:
      pvc_default: # These settings should reflect the initial configuration of the image registry. View the configuration with: $ oc get configs.imageregistry.operator.openshift.io/cluster -o yaml
        name: image-registry-storage # The name of the PVC that the image registry should use.
        defaultRoute: False # Whether or not to create a defualt route for the image registry.
        accessModes:
          - ReadWriteMany # The requested access mode that a PV must provide.
        storage: 100Gi # The requested size of the PVC.
        storageClassName: nfs-storage # The name of the storage class used for the PVC.
        volumeMode: Filesystem # Use `Filesystem` with the `nfs-storage` class.
      pvc_ocs: # These settings are for the new PVC.
        name: ocs-image-registry-storage # Choose any name that you want.
        defaultRoute: True # If `True`, then this will create a route named `default-route` in the `openshift-image-registry` namespace pointing to `default-route-openshift-image-registry.apps.ocp4.example.com`.
        accessModes:
          - ReadWriteMany
          - ReadWriteMany # The requested access mode that a PV must provide.
        storage: 100Gi # The requested size of the PVC.
        storageClassName: ocs-storagecluster-cephfs # The name of the storage class used for the PVC.
        volumeMode: Filesystem # Use `Filesystem` with the `ocs-storagecluster-cephfs` storage class.

Dependencies
------------

This role requires that you access the OpenShift cluster as a user with the cluster-admin role. The lab user on the utility machine can run commands as the system:admin user using the kubeconfig file located at /home/lab/ocp4/auth/kubeconfig.

Example Playbook
----------------

The following variables could be defined in `host_vars/utility`:

    ocp_cluster:
      host: "https://api.ocp4.example.com:6443"
      kubeconfig: /home/lab/ocp4/auth/kubeconfig
      validate_certs: False

    registry:
      pvc_default:
        name: image-registry-storage
        defaultRoute: False
        accessModes:
          - ReadWriteMany
        storage: 100Gi
        storageClassName: nfs-storage
        volumeMode: Filesystem
      pvc_ocs:
        name: ocs-image-registry-storage
        defaultRoute: True
        accessModes:
          - ReadWriteMany
        storage: 100Gi
        storageClassName: ocs-storagecluster-cephfs
        volumeMode: Filesystem

Assuming the variables have been defined (and assuming that OpenShift Container Storage has been installed and configured), the internal image registry can be configured to use OpenShift Conatiner Storage with:

    - name: Configure storage for the internal image registry
      hosts: utility
      remote_user: lab
      gather_facts: False
      module_defaults:
        group/k8s:
          host: "{{ ocp_cluster['host'] }}"
          kubeconfig: /home/lab/ocp4/auth/kubeconfig
          validate_certs: False

      roles:
        - role: ocp-ocs-registry
          mode: add

License
-------

BSD

Author Information
------------------

An optional section for the role authors to include contact information, or a website (HTML is not allowed).
