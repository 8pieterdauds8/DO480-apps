import os
import requests
import yaml

from labs.lab import LabError
from kubernetes import config
from kubernetes.client import ApiClient, Configuration
from openshift.dynamic import DynamicClient
from openshift.dynamic.resource import ResourceInstance
from requests.status_codes import codes as httpCodes
from requests_oauthlib import OAuth2Session
from six.moves.urllib_parse import urlparse, parse_qs, urlencode
from typing import Dict
from urllib3 import disable_warnings
from urllib3.exceptions import InsecureRequestWarning
from urllib3.util import make_headers


class OAuthException(Exception):
    pass


# Default location for kubeconfig, this is normally set to ~/.kube/config
kubeconfig_location = "~/.grading/kubeconfig"


def disableInsecureRequestWarning() -> None:
    """
    Disables self-signed certificate warnings
    """
    disable_warnings(InsecureRequestWarning)


def getKubeClient(location: str = kubeconfig_location) -> ApiClient:
    """
    Return a Kubernetes client object for specified kubeconfig
    """
    location = os.path.expanduser(location)

    config.load_kube_config(location)

    return ApiClient()


def getOAuthInfo(
    apiEndpoint: str,
    verifyCertificate: bool = False
) -> Dict[str, str]:
    """
    Gets the OAuth information from a specified OpenShift API endpoint.

    :param apiEndpoint: OpenShift API endpoint
    :param verifyCertificate: Flag used to verify the OpenShift API
    endpoint certificate
    :return: OAuth information
    """
    url = '{0}/.well-known/oauth-authorization-server'.format(apiEndpoint)
    response = requests.get(url, verify=verifyCertificate)

    if response.status_code != httpCodes.ok:
        raise OAuthException('Unable to find OAuth API')

    try:
        oAuthInfo = response.json()

        return {
            'authorization_endpoint': oAuthInfo['authorization_endpoint'],
            'token_endpoint': oAuthInfo['token_endpoint']
        }
    except Exception:
        raise OAuthException('Unable to parse OAuth response')


def getOpenShiftClient(location: str = kubeconfig_location) -> DynamicClient:
    """
    Return an OpenShift client object for specified kubeconfig
    """
    return DynamicClient(getKubeClient(location))


def getProjects(ocpClient: DynamicClient) -> ResourceInstance:
    """
    Returns the list of projects owned by a user.

    :param ocpClient: OpenShift client to be used to authenticate
    against the API
    :return: list of projects
    """
    return ocpClient.resources.get(
        api_version='project.openshift.io/v1',
        kind='Project'
    ).get()


def hitRoute(routeUrl: str, verifyCertificate: bool = False) -> bool:
    """
    See if the OpenShift Router answers a particular route URL
    """
    disableInsecureRequestWarning()

    try:
        response = requests.get(routeUrl, verify=verifyCertificate)
    except Exception:
        return False

    return response.status_code == httpCodes.ok


def isApiUp(
    apiEndpoint: str,
    port: str = "6443",
    verifyCertificate: bool = False
) -> bool:
    """
    See if the OpenShift API endpoint is receiving traffic
    """
    disableInsecureRequestWarning()
    endpoint = "https://{0}:{1}/version".format(apiEndpoint, port)

    try:
        response = requests.get(
            endpoint,
            verify=verifyCertificate,
            params={'timeout': '10s'}
        )
    except Exception:
        return False

    response.status_code == httpCodes.ok and response.json()['major'] == '1'
    return response.status_code


def loginAs(username: str, password: str, apiEndpoint: str) -> DynamicClient:
    """
    Authenticates against a specific OpenShift API endpoint
    providing a user and a password.

    :param username:
    :param password:
    :param apiEndpoint:
    :return: OpenShift client
    """
    disableInsecureRequestWarning()

    oAuthInfo = getOAuthInfo(apiEndpoint)
    accessToken = oAuthLogin(
        oAuthInfo['authorization_endpoint'],
        oAuthInfo['token_endpoint'],
        username,
        password
    )

    configuration = Configuration()
    configuration.host = apiEndpoint
    configuration.verify_ssl = False
    configuration.api_key = {'authorization': 'Bearer {0}'.format(accessToken)}

    return DynamicClient(ApiClient(configuration))


def oAuthLogin(
    authEndpoint: str,
    tokenEndpoint: str,
    authUsername: str,
    authPassword: str,
    verifyCertificate: bool = False,
) -> str:
    """
    Authenticates against OpenShift using OAuth.

    :param authEndpoint: OpenShift OAuth endpoint
    :param tokenEndpoint: OpenShift token endpoint
    :param authUsername: OAuth username
    :param authPassword: OAuth password
    :param verifyCertificate: A flag used to verify certificates
    :return: an access token
    """
    session = OAuth2Session(client_id='openshift-challenging-client')

    authorizationUrl, state = session.authorization_url(
        authEndpoint,
        state='1',
        code_challenge_method='S256'
    )

    authHeaders = make_headers(
        basic_auth='{0}:{1}'.format(authUsername, authPassword)
    )

    # Request authorization code using basic auth credentials
    response = session.get(
        authorizationUrl,
        headers={
            'X-Csrf-Token': state,
            'authorization': authHeaders.get('authorization')
        },
        verify=verifyCertificate,
        allow_redirects=False
    )

    if response.status_code != httpCodes.found:
        raise OAuthException('Authorization failed')

    qwargs = {}
    for k, v in parse_qs(urlparse(response.headers['Location']).query).items():
        qwargs[k] = v[0]
    qwargs['grant_type'] = 'authorization_code'

    # Using authorization code given to us in the Location header
    # of the previous request, request a token
    response = session.post(
        tokenEndpoint,
        headers={
            'Accept': 'application/json',
            'Content-Type': 'application/x-www-form-urlencoded',
            # This is just base64 encoded 'openshift-challenging-client:'
            'Authorization': 'Basic b3BlbnNoaWZ0LWNoYWxsZW5naW5nLWNsaWVudDo='
        },
        data=urlencode(qwargs),
        verify=verifyCertificate
    )

    if response.status_code != httpCodes.ok:
        OAuthException('Failed to obtain an authorization token')

    return response.json()['access_token']


def apply_resource(
        oc_client,
        resource_file,
        api_version,
        kind,
        namespace="default",
        verb="create",
):
    """
    Wrapper to create openshift resource from file
    """
    ret_val = {}
    disable_warnings(InsecureRequestWarning)
    try:
        v1_resources = oc_client.resources.get(
            api_version=api_version, kind=kind
        )
        with open(resource_file) as resource_yaml:
            resource = yaml.safe_load(resource_yaml)
            if verb == "create":
                resp = v1_resources.create(body=resource, namespace=namespace)
            elif verb == "patch":
                resp = v1_resources.patch(body=resource, namespace=namespace)
            else:
                raise LabError("ocp.api.apply_resource can only be called " +
                               "with the 'create' and 'patch' verbs")
            ret_val["resp"] = resp
        ret_val["Failed"] = False
    except Exception as e:
        ret_val["Failed"] = True
        ret_val["msgs"] = [
            {
                "text": "Could not create '{}' ".format(kind) +
                "resource from file: {}".format(resource_file)
            }
        ]
        ret_val["exception"] = {
            "name": e.__class__.__name__,
            "message": str(e),
        }
