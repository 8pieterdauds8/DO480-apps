Role Name
=========

Use this role to add or remove one or more node labels.

Courses using this role:
  - DO370

Requirements
------------

In order to use Ansible to manage Kubernetes, this role requires RPMs that are not available from the typical repositories.
- The lab grading framework installs the package dependencies in a virtual environment using pip.

Role Variables
--------------

nodes: A list of nodes that will be labeled.

Example:

       nodes:
         - worker01
         - worker02

labels: A list of one or more labels to either add or remove.
To remove a label, set the value of the label to 'null'.
For example, to remove the 'node-role.kubernetes.io/infra' label, use: "node-role.kubernetes.io/infra: null".

Example:

        labels:
          - "node-role.kubernetes.io/infra: null"
          - "node-role.kubernetes.io/worker: ''"
          - "cluster.ocs.openshift.io/openshift-storage: ''"
          - "env: 'prod'"

Dependencies
------------

This role requires that you access the OpenShift cluster as a user with the cluster-admin role. The lab user on the utility machine can run commands as the system:admin user using the kubeconfig file located at /home/lab/ocp4/auth/kubeconfig.

Example Playbook
----------------

The following variables could be defined in `host_vars/utility`:

        ocp_cluster:
          host: "https://api.ocp4.example.com:6443"
          kubeconfig: /home/lab/ocp4/auth/kubeconfig
          validate_certs: False

Assuming the variables have been defined, worker01, worker02, and worker03 can be labeled in the following ways:
  - Remove the `node-role.kubernetes.io/infra=` label.
  - Add the `node-role.kubernetes.io/worker=` label.
  - Add the `cluster.ocs.openshift.io/openshift-storage=` label.

        - name: Label nodes
          hosts: utility
          remote_user: lab
          gather_facts: False
          module_defaults:
            group/k8s:
              host: "{{ ocp_cluster['host'] }}"
              kubeconfig: /home/lab/ocp4/auth/kubeconfig
              validate_certs: False

          roles:
            - role: ocp-label-node
              nodes:
                - worker01
                - worker02
                - worker03
              labels:
                - "node-role.kubernetes.io/infra: null"
                - "node-role.kubernetes.io/worker: ''"
                - "cluster.ocs.openshift.io/openshift-storage: ''"

License
-------

BSD

Author Information
------------------

An optional section for the role authors to include contact information, or a website (HTML is not allowed).
